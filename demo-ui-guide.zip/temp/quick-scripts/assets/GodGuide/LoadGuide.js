(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/GodGuide/LoadGuide.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '221183HlFFC8a1pFSY4mraA', 'LoadGuide', __filename);
// GodGuide/LoadGuide.js

'use strict';

var task1 = require('task1');

cc.Class({

    extends: cc.Component,
    properties: {
        PREFAB: cc.Prefab, //预制件
        parent: cc.Node, //预制件实例化后所在的父节点
        zIndex: 0
    },

    onLoad: function onLoad() {
        if (!CC_EDITOR) {
            this.loadPrefab();
        }
    },
    start: function start() {
        this.runTask();
    },
    loadPrefab: function loadPrefab() {
        try {
            var node = cc.instantiate(this.PREFAB);
            node.zIndex = this.zIndex;
            //不持久化到编辑器
            node._objFlags = cc.Object.Flags.DontSave;
            node.parent = this.parent || this.node;
            this._godGuide = node.getComponent('GodGuide');
        } catch (error) {
            cc.error(this.PREFAB);
            cc.error(error);
        }
    },
    runTask: function runTask() {
        this._godGuide.setTask(task1);
        this._godGuide.run();
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=LoadGuide.js.map
        