(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/GodGuide/GodCommand.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'c169bytmm9MH4v26IPKf9RD', 'GodCommand', __filename);
// GodGuide/GodCommand.js

'use strict';

/**
 * zxh
 */

var GodCommand = {
    //定位节点
    locator: function locator(godGuide, step, callback) {
        var args = step.command.args;

        godGuide.find(args, function (node) {
            godGuide._targetNode = node;
            var autorun = godGuide.getTask().autorun;

            //点击确认
            node.once(cc.Node.EventType.TOUCH_END, function () {
                cc.log('节点被点击');
                //任务完成
                callback();
            });
        });
    },


    //定位节点，显示一个手指动画
    finger: function finger(godGuide, step, callback) {
        var args = step.command.args;
        //定位节点

        godGuide.find(args, function (node) {
            godGuide._targetNode = node;
            //手指动画
            godGuide.fingerToNode(node, function () {
                //点击确认
                node.once(cc.Node.EventType.TOUCH_END, function () {
                    cc.log('节点被点击');
                    //任务完成
                    callback();
                });
            });

            //触摸模拟
            var autorun = godGuide.getTask().autorun;
            if (autorun) {
                godGuide.touchSimulation(node);
            }
        });
    }
};

GodCommand.LOCATOR = 'locator';
GodCommand.FINGER = 'finger';

module.exports = GodCommand;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GodCommand.js.map
        