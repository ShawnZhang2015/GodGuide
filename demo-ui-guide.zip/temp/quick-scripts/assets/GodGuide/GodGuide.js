(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/GodGuide/GodGuide.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '7b174OZGvJOjZrsLqOTxm98', 'GodGuide', __filename);
// GodGuide/GodGuide.js

'use strict';

var locator = require('locator');
var godCommand = require('GodCommand');

var RADIAN = 2 * Math.PI / 360;

function getRotatePoint(p, angle, center) {
    var out = cc.v2();
    var radian = -angle * RADIAN;
    out.x = (p.x - center.x) * Math.cos(radian) - (p.y - center.y) * Math.sin(radian) + center.x;
    out.y = (p.x - center.x) * Math.sin(radian) + (p.y - center.y) * Math.cos(radian) + center.y;
    return out;
}

function getRectRotatePoints(rect, angle, pt) {
    var array = [cc.v2(rect.x, rect.y), cc.v2(rect.x + rect.width, rect.y), cc.v2(rect.x + rect.width, rect.y + rect.height), cc.v2(rect.x, rect.y + rect.height)];
    return array.map(function (p) {
        return getRotatePoint(p, angle, pt);
    });
}

function getHTMLElementPosition(element) {
    element = element || document.getElementById("GameCanvas");
    var docElem = document.documentElement;
    var win = window;
    var box = null;
    if (element.getBoundingClientRect) {
        box = element.getBoundingClientRect();
    } else {
        if (element instanceof HTMLCanvasElement) {
            box = {
                left: 0,
                top: 0,
                width: element.width,
                height: element.height
            };
        } else {
            box = {
                left: 0,
                top: 0,
                width: parseInt(element.style.width),
                height: parseInt(element.style.height)
            };
        }
    }
    return {
        left: box.left + win.pageXOffset - docElem.clientLeft,
        top: box.top + win.pageYOffset - docElem.clientTop,
        width: box.width,
        height: box.height
    };
}

function _touchSimulation(x, y) {
    var canvas = document.getElementById("GameCanvas");
    var rect = _cc.inputManager.getHTMLElementPosition(canvas); //getHTMLElementPosition(canvas);
    var pt = cc.v2(x + rect.left, rect.top + rect.height - y);

    var mousedown = document.createEvent("MouseEvent");
    mousedown.initMouseEvent("mousedown", true, true, window, 0, 0, 0, pt.x, pt.y, true, false, false, false, 0, null);
    canvas.dispatchEvent(mousedown);
    setTimeout(function () {
        var mouseup = document.createEvent("MouseEvent");
        mouseup.initMouseEvent("mouseup", true, true, window, 0, 0, 0, pt.x, pt.y, true, false, false, false, 0, null);
        canvas.dispatchEvent(mouseup);
    }, 100);
}

//---------------------------
var GodGuide = cc.Class({
    extends: cc.Component,
    properties: {
        _selector: '',
        selector: {
            get: function get() {
                return this._selector;
            },
            set: function set(value) {
                this._selector = value;
                this.find(value);
            }
        },

        type: {
            default: cc.Mask.Type.RECT,
            type: cc.Mask.Type
        },

        FINGER_PREFAB: cc.Prefab
    },

    statics: {
        find: function find(path, cb) {
            var root = cc.find('Canvas');
            locator.locateNode(root, path, cb);
        },
        touchSimulation: function touchSimulation(node) {
            var p = node.parent.convertToWorldSpaceAR(node.position);
            _touchSimulation(p.x, p.y);
        }
    },

    onLoad: function onLoad() {
        this._targetNode = null;
        if (this.FINGER_PREFAB) {
            this._finger = cc.instantiate(this.FINGER_PREFAB);
            this._finger.parent = this.node;
            this._finger.active = false;
        }
        this.node.setContentSize(cc.winSize);
        window.GodGuide = this;
    },
    touchSimulation: function touchSimulation(node) {
        this.log('自动执行，模拟触摸');
        this.scheduleOnce(function () {
            cc.log('自动节点 :', JSON.stringify(node.position));
            var p = node.parent.convertToWorldSpaceAR(node.position);
            cc.log('世界节点 :', JSON.stringify(p));
            _touchSimulation(p.x, p.y);
        }, 1);
    },
    init: function init() {
        var _this = this;

        //获取遮罩组件 
        this._mask = this.node.getComponentInChildren(cc.Mask);
        this._mask.inverted = true;

        this.node.on(cc.Node.EventType.TOUCH_START, function (event) {
            //放行
            if (!_this._mask.node.active) {
                _this.node._touchListener.setSwallowTouches(false);
                return;
            }

            //目标节点不存在，拦截
            if (!_this._targetNode) {
                _this.node._touchListener.setSwallowTouches(true);
                return;
            }

            //目标区域存在，击中放行
            var rect = _this._targetNode.getBoundingBoxToWorld();
            if (rect.contains(event.getLocation())) {
                _this.node._touchListener.setSwallowTouches(false);
                cc.log('未命中目标节点，放行');
            } else {
                _this.node._touchListener.setSwallowTouches(true);
                cc.log('未命中目标节点，拦截');
            }
        }, this);
    },
    start: function start() {
        cc.debug.setDisplayStats(false);
        this.init();
    },
    setTask: function setTask(task) {
        if (this._task) {
            cc.warn('当前任务还未处理完毕！');
            return;
        }
        this._task = task;
    },
    getTask: function getTask() {
        return this._task;
    },
    run: function run() {
        var _this2 = this;

        if (!this._task) {
            return;
        }

        async.eachSeries(this._task.steps, function (step, cb) {
            _this2._processStep(step, cb);
        }, function () {
            _this2._task = null;
            cc.log('任务结束');
            _this2._mask.node.active = false;
            if (_this2._finger) {
                _this2._finger.active = false;
            }
        });
    },
    fillPoints: function fillPoints(points) {
        var _this3 = this;

        var p0 = points[0];
        this._mask._graphics.moveTo(p0.x, p0.y);
        points.slice(1).forEach(function (p) {
            _this3._mask._graphics.lineTo(p.x, p.y);
        });
        this._mask._graphics.lineTo(p0.x, p0.y);
        this._mask._graphics.stroke();
        this._mask._graphics.fill();
    },
    _processStep: function _processStep(step, callback) {
        var _this4 = this;

        async.series({
            //任务开始
            stepStart: function stepStart(cb) {
                if (step.onStart) {
                    step.onStart(function () {
                        cb();
                    });
                } else {
                    cb();
                }
            },


            //任务指令
            stepCommand: function stepCommand(cb) {
                _this4.scheduleOnce(function () {
                    _this4._processStepCommand(step, function () {
                        cb();
                    });
                }, step.delayTime || 0);
            },

            //任务结束
            taskEnd: function taskEnd(cb) {
                _this4._mask._graphics.clear();
                _this4._finger.active = false;
                if (step.onEnd) {
                    task.onEnd(function () {
                        cb();
                    });
                } else {
                    cb();
                }
            }
        }, function (error) {
            _this4.log('\u6B65\u9AA4\u3010' + step.desc + '\u3011\u7ED3\u675F\uFF01');
            callback();
        });
    },


    /**
     * 手指动画
     */
    fingerToNode: function fingerToNode(node, cb) {
        if (!this._finger) {
            cb();
        }

        this._finger.active = true;
        // let rect = node.getBoundingBoxToWorld();
        // let p = this.node.convertToNodeSpaceAR(rect.origin);   
        // p = cc.v2(p.x + rect.width * 0.5, p.y + rect.height * 0.5);
        var p = this.node.convertToNodeSpaceAR(node.parent.convertToWorldSpaceAR(node.position));

        var duration = p.sub(this._finger.position).mag() / cc.winSize.height;
        var moveTo = cc.moveTo(duration, p);
        var callFunc = cc.callFunc(function () {
            cb();
        });

        var sequnce = cc.sequence(moveTo, callFunc);
        this._finger.runAction(sequnce);
    },
    log: function log(text) {
        if (this._task.debug) {
            cc.log(text);
        }
    },


    /**
     * 处理步骤指令
     * @param {*} step 
     * @param {*} cb 
     */
    _processStepCommand: function _processStepCommand(step, cb) {
        var _this5 = this;

        var func = godCommand[step.command.cmd];
        if (func) {
            this.log('\u6267\u884C\u6B65\u9AA4\u3010' + step.desc + '\u3011\u6307\u4EE4: ' + step.command.cmd);
            func.call(this, this, step, function () {
                _this5.log('\u6B65\u9AA4\u3010' + step.desc + '\u3011\u6307\u4EE4: ' + step.command.cmd + ' \u6267\u884C\u5B8C\u6BD5');
                cb();
            });
        } else {
            this.log('\u6267\u884C\u6B65\u9AA4\u3010' + step.desc + '\u3011\u6307\u4EE4: ' + step.command.cmd + ' \u4E0D\u5B58\u5728\uFF01');
            cb();
        }
    },
    find: function find(value, cb) {
        var _this6 = this;

        var root = cc.find('Canvas');
        locator.locateNode(root, value, function (error, node) {
            if (error) {
                cc.log(error);
                return;
            }
            cc.log('定位节点成功');
            var rect = _this6._focusToNode(node);
            if (cb) {
                cb(node, rect);
            }
        });
    },
    locateNodeByEvent: function locateNodeByEvent(sender) {
        this.selector = sender.string;
    },
    getNodePoints: function getNodePoints(rect, angle, pt) {
        return getRectRotatePoints(rect, angle, pt).map(function (p) {
            return p;
        });
    },
    fillPolygon: function fillPolygon(points) {
        var _this7 = this;

        var p0 = points[0];
        this._mask._graphics.moveTo(p0.x, p0.y);
        points.slice(1).forEach(function (p) {
            _this7._mask._graphics.lineTo(p.x, p.y);
        });
        this._mask._graphics.lineTo(p0.x, p0.y);
        this._mask._graphics.stroke();
        this._mask._graphics.fill();
    },
    _focusToNode: function _focusToNode(node) {
        this._mask._graphics.clear();
        var rect = node.getBoundingBoxToWorld();
        var p = this.node.convertToNodeSpaceAR(rect.origin);
        rect.x = p.x;
        rect.y = p.y;

        this._mask._graphics.fillRect(rect.x, rect.y, rect.width, rect.height);
        return rect;
    },


    /**
     * 记得触摸节点
     */
    startRecordTouchNode: function startRecordTouchNode() {
        if (this._dispatchEvent) {
            return;
        }

        this._dispatchEvent = cc.Node.prototype.dispatchEvent;
        var self = this;
        this._touchNodes = [];
        cc.Node.prototype.dispatchEvent = function (event) {
            self._dispatchEvent.call(this, event);
            if (event.currentTarget !== self.node && event.type === cc.Node.EventType.TOUCH_END) {
                var path = locator.getNodeFullPath(this);
                self._touchNodes.push({ node: this, path: path, points: null });
                cc.log(event.type, ':', path);
            }
        };
    },


    /**
     * 停止记录
     */
    stopRecordTouchNode: function stopRecordTouchNode() {
        if (this._dispatchEvent) {
            cc.Node.prototype.dispatchEvent = this._dispatchEvent;
            this._dispatchEvent = null;
        }
    },
    playRecordTouchNode: function playRecordTouchNode() {
        var _this8 = this;

        this.stopRecordTouchNode();
        async.eachLimit(this._touchNodes, 1, function (item, cb) {
            _this8._targetGuide = item;
            _this8.find(item.path, function (node) {
                var touchEnd = function touchEnd() {
                    _this8._currentNode = null;
                    cc.log('引导点击节点：', node.name);
                    cb();
                    node.off(cc.Node.EventType.TOUCH_END, touchEnd, _this8);
                };
                node.on(cc.Node.EventType.TOUCH_END, touchEnd, _this8);
            });
        }, function () {
            cc.log('任务完成');
            _this8.node.destroy();
        });
    }
});

module.exports = GodGuide;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GodGuide.js.map
        