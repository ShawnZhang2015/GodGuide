(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/GodGuide/task1.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'fff37G5RJRIaLo8tHxdrqbx', 'task1', __filename);
// GodGuide/task1.js

'use strict';

var GodCommand = require('GodCommand');
module.exports = {
    name: '进入商店',
    debug: true,
    autorun: false,
    steps: [{
        desc: '点击主界面主页按钮',
        command: { cmd: 'finger', args: 'Home > main_btns > btn_home' },
        delayTime: 1
    }, {
        desc: '点击主界面设置按钮',
        command: { cmd: GodCommand.FINGER, args: 'Home > main_btns > btn_setting' }
    }, {
        desc: '点击主界面商店按钮',
        command: { cmd: GodCommand.FINGER, args: 'Home > main_btns > btn_shop' }
    }, {
        desc: '点击商店充值按钮',
        command: { cmd: GodCommand.FINGER, args: 'Home > Shop > btnCharge' },
        delayTime: 2
    }, {
        desc: '点击充值界面关闭钮',
        command: { cmd: GodCommand.FINGER, args: 'chargePanel > btn_close' },
        delayTime: 2
    }]
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=task1.js.map
        