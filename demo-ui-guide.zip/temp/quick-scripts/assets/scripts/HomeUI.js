(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/HomeUI.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '80382PDGl1Jf4nvzaq1gyOV', 'HomeUI', __filename);
// scripts/HomeUI.js

'use strict';

var BackPackUI = require('BackPackUI');
var ShopUI = require('ShopUI');

var PanelType = cc.Enum({
    Home: -1,
    Shop: -1
});

cc.Class({
    extends: cc.Component,

    properties: {
        menuAnim: {
            default: null,
            type: cc.Animation
        },
        homeBtnGroups: {
            default: [],
            type: cc.Node
        },
        backPackUI: {
            default: null,
            type: BackPackUI
        },
        shopUI: ShopUI
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.curPanel = PanelType.Home;
        this.menuAnim.play('menu_reset');
    },

    start: function start() {
        this.backPackUI.init(this);
        this.shopUI.init(this, PanelType.Shop);
        this.scheduleOnce(function () {
            this.menuAnim.play('menu_intro');
        }.bind(this), 0.5);
    },

    toggleHomeBtns: function toggleHomeBtns(enable) {
        for (var i = 0; i < this.homeBtnGroups.length; ++i) {
            var group = this.homeBtnGroups[i];
            if (!enable) {
                group.pauseSystemEvents(true);
            } else {
                group.resumeSystemEvents(true);
            }
        }
    },

    gotoShop: function gotoShop() {
        if (this.curPanel !== PanelType.Shop) {
            this.shopUI.show();
        }
    },

    gotoHome: function gotoHome() {
        if (this.curPanel === PanelType.Shop) {
            this.shopUI.hide();
            this.curPanel = PanelType.Home;
        }
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=HomeUI.js.map
        