(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/tabs/TabCtrl.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '62208XJq9ZC2oNDeQGcbCab', 'TabCtrl', __filename);
// scripts/tabs/TabCtrl.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        idx: 0,
        icon: cc.Sprite,
        arrow: cc.Node,
        anim: cc.Animation
    },

    // use this for initialization
    init: function init(tabInfo) {
        // sidebar, idx, iconSF
        this.sidebar = tabInfo.sidebar;
        this.idx = tabInfo.idx;
        this.icon.spriteFrame = tabInfo.iconSF;
        this.node.on('touchstart', this.onPressed.bind(this), this.node);
        this.arrow.scale = cc.v2(0, 0);
    },
    onPressed: function onPressed() {
        this.sidebar.tabPressed(this.idx);
    },
    turnBig: function turnBig() {
        this.anim.play('tab_turn_big');
    },
    turnSmall: function turnSmall() {
        this.anim.play('tab_turn_small');
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=TabCtrl.js.map
        