(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/tabs/MainMenu.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '1bc0eZACFdK24h0UsytreOq', 'MainMenu', __filename);
// scripts/tabs/MainMenu.js

'use strict';

var MenuSidebar = require('MenuSidebar');

cc.Class({
    extends: cc.Component,

    properties: {
        sidebar: MenuSidebar,
        roller: cc.Node,
        panelWidth: 0,
        tabSwitchDuration: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.sidebar.init(this);
        this.curPanelIdx = 0;
        this.roller.x = this.curPanelIdx * -this.panelWidth;
    },
    switchPanel: function switchPanel(idx) {
        this.curPanelIdx = idx;
        var newX = this.curPanelIdx * -this.panelWidth;
        var rollerMove = cc.moveTo(this.tabSwitchDuration, cc.v2(newX, 0)).easing(cc.easeQuinticActionInOut());
        var callback = cc.callFunc(this.onSwitchPanelFinished, this);
        this.roller.stopAllActions();
        this.roller.pauseSystemEvents(true);
        this.roller.runAction(cc.sequence(rollerMove, callback));
    },
    onSwitchPanelFinished: function onSwitchPanelFinished() {
        this.roller.resumeSystemEvents(true);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MainMenu.js.map
        