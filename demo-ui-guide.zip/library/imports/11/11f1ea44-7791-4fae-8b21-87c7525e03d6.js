"use strict";
cc._RF.push(module, '11f1epEd5FProshh8dSXgPW', 'ChargeUI');
// scripts/ChargeUI.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    init: function init(home, parentBtns) {
        this.home = home;
        this.parentBtns = parentBtns;
    },

    show: function show() {
        this.node.active = true;
        this.node.emit('fade-in');
        this.home.toggleHomeBtns(false);
        this.parentBtns.pauseSystemEvents();
    },

    hide: function hide() {
        this.node.emit('fade-out');
        this.home.toggleHomeBtns(true);
        this.parentBtns.resumeSystemEvents();
    }
});

cc._RF.pop();