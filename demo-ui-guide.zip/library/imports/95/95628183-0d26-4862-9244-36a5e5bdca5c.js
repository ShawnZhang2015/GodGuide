"use strict";
cc._RF.push(module, '95628GDDSZIYpJENqXlvcpc', 'MenuSidebar');
// scripts/tabs/MenuSidebar.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        tabIcons: {
            default: [],
            type: cc.SpriteFrame
        },
        tabPrefab: cc.Prefab,
        container: cc.Node,
        highlight: cc.Node,
        tabWidth: 0
    },

    // use this for initialization
    init: function init(mainMenu) {
        this.mainMenu = mainMenu;
        this.tabSwitchDuration = mainMenu.tabSwitchDuration;
        this.curTabIdx = 0;
        this.tabs = [];
        for (var i = 0; i < this.tabIcons.length; ++i) {
            var iconSF = this.tabIcons[i];
            var tab = cc.instantiate(this.tabPrefab).getComponent('TabCtrl');
            this.container.addChild(tab.node);
            tab.init({
                sidebar: this,
                idx: i,
                iconSF: iconSF
            });
            this.tabs[i] = tab;
        }
        this.tabs[this.curTabIdx].turnBig();
        this.highlight.x = this.curTabIdx * this.tabWidth;
    },
    tabPressed: function tabPressed(idx) {
        for (var i = 0; i < this.tabs.length; ++i) {
            var tab = this.tabs[i];
            if (tab.idx === idx) {
                tab.turnBig();
                tab.node.pauseSystemEvents();
            } else if (this.curTabIdx === tab.idx) {
                tab.turnSmall();
                tab.node.resumeSystemEvents();
            }
        }
        this.curTabIdx = idx;
        var highlightMove = cc.moveTo(this.tabSwitchDuration, cc.v2(this.curTabIdx * this.tabWidth)).easing(cc.easeQuinticActionInOut());
        this.highlight.stopAllActions();
        this.highlight.runAction(highlightMove);
        this.mainMenu.switchPanel(this.curTabIdx);
    }
});

cc._RF.pop();