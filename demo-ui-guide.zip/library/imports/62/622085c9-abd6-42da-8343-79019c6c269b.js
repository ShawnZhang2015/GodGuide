"use strict";
cc._RF.push(module, '62208XJq9ZC2oNDeQGcbCab', 'TabCtrl');
// scripts/tabs/TabCtrl.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        idx: 0,
        icon: cc.Sprite,
        arrow: cc.Node,
        anim: cc.Animation
    },

    // use this for initialization
    init: function init(tabInfo) {
        // sidebar, idx, iconSF
        this.sidebar = tabInfo.sidebar;
        this.idx = tabInfo.idx;
        this.icon.spriteFrame = tabInfo.iconSF;
        this.node.on('touchstart', this.onPressed.bind(this), this.node);
        this.arrow.scale = cc.v2(0, 0);
    },
    onPressed: function onPressed() {
        this.sidebar.tabPressed(this.idx);
    },
    turnBig: function turnBig() {
        this.anim.play('tab_turn_big');
    },
    turnSmall: function turnSmall() {
        this.anim.play('tab_turn_small');
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

});

cc._RF.pop();