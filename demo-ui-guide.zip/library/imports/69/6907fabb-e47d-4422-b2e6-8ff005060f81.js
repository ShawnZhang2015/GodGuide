"use strict";
cc._RF.push(module, '6907fq75H1EIrLmj/AFBg+B', 'SubBtnsUI');
// scripts/SubBtnsUI.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        subBtnsAnim: cc.Animation,
        btnShowSub: cc.Button,
        btnHideSub: cc.Button,
        btnContainer: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.btnShowSub.node.active = true;
        this.btnHideSub.node.active = false;
    },

    showSubBtns: function showSubBtns() {
        this.btnContainer.active = true;
        this.subBtnsAnim.play('sub_pop');
    },

    hideSubBtns: function hideSubBtns() {
        this.subBtnsAnim.play('sub_fold');
    },

    onFinishAnim: function onFinishAnim(finishFold) {
        this.btnShowSub.node.active = finishFold;
        this.btnHideSub.node.active = !finishFold;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();